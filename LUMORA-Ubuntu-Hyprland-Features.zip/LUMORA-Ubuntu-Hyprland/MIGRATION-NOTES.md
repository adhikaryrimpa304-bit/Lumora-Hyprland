# Migration notes

- This is a clean Ubuntu + Hyprland branch, not an in-place patch of the old Debian GNOME ISO.
- Original LUMORA logo/wallpaper assets are retained.
- GNOME shell extensions, dconf configuration, GDM-specific styling, Calamares Debian settings, and old Debian live-build hooks are intentionally excluded.
- The old ZIP was not modified.
- No ISO build, runtime launch test, or installer test was performed while generating this scaffold.
- Ubuntu live-build compatibility and package availability are the first engineering tasks to verify.

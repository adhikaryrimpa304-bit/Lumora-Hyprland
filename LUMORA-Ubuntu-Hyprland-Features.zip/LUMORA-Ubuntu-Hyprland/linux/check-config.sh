#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
echo 'Checking LUMORA Hyprland source tree…'
for f in   "$ROOT/linux/package-list.txt"   "$ROOT/linux/overlay/includes.chroot/etc/skel/.config/hypr/hyprland.conf"   "$ROOT/linux/overlay/includes.chroot/etc/skel/.config/waybar/config"   "$ROOT/linux/overlay/includes.chroot/usr/bin/lumora-welcome"; do
  [[ -s "$f" ]] || { echo "Missing/empty: $f" >&2; exit 1; }
  echo "OK: ${f#"$ROOT"/}"
done
bash -n "$ROOT/linux/build-iso.sh"
bash -n "$ROOT/linux/overlay/includes.chroot/usr/bin/lumora-welcome"
for f in lumora-hub lumora-system-info lumora-wallpapers lumora-recovery; do
  python3 -m py_compile "$ROOT/linux/overlay/includes.chroot/usr/bin/$f"
done
for f in lumora-update lumora-installer; do
  bash -n "$ROOT/linux/overlay/includes.chroot/usr/bin/$f"
done
for f in lumora-hub.desktop lumora-system-info.desktop lumora-wallpapers.desktop lumora-update.desktop lumora-recovery.desktop lumora-installer.desktop; do
  [[ -s "$ROOT/linux/overlay/includes.chroot/usr/share/applications/$f" ]] || { echo "Missing desktop entry: $f" >&2; exit 1; }
done
# Catch duplicate package entries and blank/comment lines are ignored.
awk '!/^#/ && NF {print $1}' "$ROOT/linux/package-list.txt" | sort | uniq -d | while read -r p; do echo "Duplicate package: $p"; done
echo 'Static source checks passed. This does not validate Ubuntu package availability or prove the ISO boots.'
